package org.example;

import PatterFactory.IcmsFactory;
import java.awt.BorderLayout;
import java.math.BigDecimal;
import modelo.Orcamento;

public class Main {

    public static void main(String args[]) {

        Orcamento orcamento = new Orcamento(new BigDecimal("1000"),"ICMS_MG");
        IcmsFactory icmsfactory = new IcmsFactory();

        BigDecimal resultado = icmsfactory.getIcmsPorEstado("ICMS_MG").calculoPorRegiao(orcamento);

        System.out.println(resultado);
    }
}
