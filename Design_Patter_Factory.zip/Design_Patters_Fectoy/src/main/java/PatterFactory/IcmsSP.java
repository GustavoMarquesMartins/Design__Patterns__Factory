package PatterFactory;

import java.math.BigDecimal;
import java.math.MathContext;
import modelo.Orcamento;

public class IcmsSP implements CalculoPorRegiao {

    @Override
    public BigDecimal calculoPorRegiao(Orcamento orcamento) {
        return orcamento.valorOrcamento.multiply(new BigDecimal("0.12"));
    }

}
